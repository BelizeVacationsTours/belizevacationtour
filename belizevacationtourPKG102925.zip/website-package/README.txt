===================================================================
BELIZE VACATION TOUR - WEBSITE DEPLOYMENT PACKAGE
www.belizevacationtour.com
===================================================================

EVERYTHING YOU NEED IS IN THIS FOLDER!

Contents:
✓ index.html - Your complete website
✓ images/ - All 7 beautiful AI-generated tour photos

===================================================================
STEP-BY-STEP: PUBLISH YOUR WEBSITE IN 10 MINUTES
===================================================================

STEP 1: DOWNLOAD THIS ENTIRE FOLDER
------------------------------------
In Replit, download the "website-package" folder to your computer.
Make sure you get both index.html and the images folder.


STEP 2: SIGN UP FOR FREE HOSTING (NETLIFY)
-------------------------------------------
1. Open your web browser
2. Go to: https://app.netlify.com/signup
3. Sign up with your email (it's 100% free, no credit card needed)
4. Verify your email if asked


STEP 3: DEPLOY YOUR WEBSITE (DRAG & DROP!)
-------------------------------------------
1. After logging into Netlify, you'll see the dashboard
2. Look for "Sites" in the top menu
3. Click the big "Add new site" button
4. Choose "Deploy manually"
5. DRAG the entire "website-package" folder onto the upload area
6. Wait 30 seconds...
7. YOUR SITE IS LIVE! 🎉

Netlify will give you a URL like: https://sparkly-unicorn-123456.netlify.app
Click it to see your live website!


STEP 4: ADD YOUR CUSTOM DOMAIN
-------------------------------
Now let's change the URL to www.belizevacationtour.com

In Netlify:
1. Click on your site
2. Click "Domain settings" (or "Set up a custom domain")
3. Click "Add custom domain"
4. Type: www.belizevacationtour.com
5. Click "Verify"
6. Click "Add domain"

Netlify will show you DNS instructions - something like:

   "Add a CNAME record:
   Name: www
   Value: sparkly-unicorn-123456.netlify.app"

Keep this page open! You'll need it for the next step.


STEP 5: UPDATE YOUR DOMAIN'S DNS
---------------------------------
Where did you buy www.belizevacationtour.com?
(GoDaddy, Namecheap, Google Domains, etc.)

1. Log in to that website
2. Find "DNS Settings" or "Manage DNS" or "DNS Management"
3. Look for "Add Record" or "Add DNS Record"
4. Add a CNAME record:
   - Type: CNAME
   - Name: www
   - Value: [your-site-name].netlify.app (from Netlify)
   - TTL: Automatic or 3600

5. Also add an A record for the root domain:
   - Type: A
   - Name: @ (or leave blank)
   - Value: 75.2.60.5 (Netlify's IP address)
   - TTL: Automatic or 3600

6. Save your changes


STEP 6: WAIT & VERIFY (15-60 minutes)
--------------------------------------
DNS changes take time to spread across the internet.

1. Wait 15-60 minutes
2. Go to: https://www.belizevacationtour.com
3. Your website should appear!
4. Netlify automatically adds HTTPS (the padlock) - totally free!

Check if it's working:
- Visit: https://www.belizevacationtour.com
- Visit: https://belizevacationtour.com (without www)
Both should work!


===================================================================
IMPORTANT NOTES
===================================================================

BOOKING FORM:
Right now, the booking form shows a success message but doesn't 
send emails. To receive actual booking requests:

Option A (Easy): Add Formspree
1. Go to formspree.io and sign up (free)
2. Create a form and get a form URL
3. I can help you update the HTML to use it

Option B (Advanced): Use email service like SendGrid
1. Requires some technical setup
2. Come back to Replit and I can help

For now, the website looks professional and works perfectly!


MAKING CHANGES:
To update your website later:
1. Edit index.html on your computer
2. Go to Netlify
3. Drag the updated files to your site
4. Changes go live instantly!


===================================================================
NEED HELP?
===================================================================

COMMON ISSUES:

"My domain isn't working after 1 hour"
→ Check your DNS settings are exactly as Netlify showed
→ Try https://dnschecker.org to see if DNS has updated
→ Contact your domain registrar support

"Images aren't showing"
→ Make sure you uploaded the entire folder with images/
→ Redeploy the whole website-package folder

"Booking form doesn't work"
→ It shows a success message but doesn't email you
→ This is normal - let me know if you want email integration


DOMAIN REGISTRAR HELP:
- GoDaddy: support.godaddy.com
- Namecheap: support.namecheap.com  
- Google Domains: support.google.com/domains

Or come back to this Replit and ask me! I'm here to help!


===================================================================
YOUR WEBSITE IS READY! 🚀
===================================================================

You're about to have a beautiful, professional website at:
https://www.belizevacationtour.com

Good luck with your tours in Belize!
